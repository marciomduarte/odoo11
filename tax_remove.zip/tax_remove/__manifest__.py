{
    'name': 'Remove all Taxes',
    'version': '10.0.1.0',
    'category': 'Sales Management',
    'summary': "Remove taxes in the Devi",
    'author': 'Márcio Duarte',
    'company': 'ProGest SA',
    'website': 'http://www.progest.ch',

    'description': """

Sale Discount for Total Amount
=======================
Module to manage discount on total amount in Sale.
        as an specific amount or percentage
""",
    'depends': ['sale'
                ],
    'data': [
        'views/tax_view.xml',
    ],
    'demo': [
    ],
    'installable': True,
}
