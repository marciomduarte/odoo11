from odoo import models, fields, api
import odoo.addons.decimal_precision as dp

class SaleOrderTax(models.Model):
    _inherit = "sale.order"

    """@api.depends('order_line.price_subtotal')
    def _amount_all(self):
        """
        """Compute the total amounts of the SO."""
        """
        for order in self:
            amount_untaxed = amount_tax = x_amount_discount = 0.0
            for line in order.order_line:
                amount_untaxed += line.price_subtotal
                amount_tax += line.price_tax
                x_amount_discount += (line.product_uom_qty * line.price_unit * line.discount)/100
            order.update({
                'amount_untaxed': order.pricelist_id.currency_id.round(amount_untaxed),
                'amount_tax': order.pricelist_id.currency_id.round(amount_tax),
                'x_amount_discount': order.pricelist_id.currency_id.round(x_amount_discount),
                'amount_total': amount_untaxed + amount_tax,
            })
    """

    tax_active = fields.boolean("Acitve/Desactive Taxes", default="False")

    @api.onchange('tax_active', 'order_line')
    def supply_rate(self):
        if self.tax_active:
            for order in self:
                for line in order.order_line:
                    line.amount_tax = 0
        else:
            for order in self:
                for line in order.order_line:
                    line.amount_tax += line.tax_id

"""
        for order in self:
            if order.discount_type == 'percent':
                for line in order.order_line:
                    line.discount = order.discount_rate
            else:
                total = discount = 0.0
                for line in order.order_line:
                    total += round((line.product_uom_qty * line.price_unit))
                if order.discount_rate != 0:
                    discount = (order.discount_rate / total) * 100
                else:
                    discount = order.discount_rate
                for line in order.order_line:
                    line.discount = discount

"""
"""    @api.multi
    def tax_active(self):
        self.supply_rate()
        return True
"""
