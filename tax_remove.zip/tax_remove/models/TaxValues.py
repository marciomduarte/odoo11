from odoo import models, fields, api
import odoo.addons.decimal_precision as dp

class SaleOrderTax(models.Model):
    _inherit = "sale.order"

    tax_active = fields.boolean("Acitve/Desactive Taxes", default="False")

    @api.onchange('tax_active', 'order_line')
    def supply_rate(self):
        if self.tax_active:
            for order in self:
                for line in order.order_line:
                    line.amount_tax = 0
        else:
            for order in self:
                for line in order.order_line:
                    line.amount_tax += line.tax_id
